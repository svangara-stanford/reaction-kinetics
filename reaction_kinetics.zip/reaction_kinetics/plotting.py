"""
Diagnostic plots. dc/dt has length T-1 and is aligned to time_mid_s (midpoints).
"""

from pathlib import Path
from typing import List

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from reaction_kinetics.schema import DescriptiveSummary, ParticleEpisode, RateMaps


def _ensure_dir(path: str) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def plot_particle_soc_curves(
    episodes: List[ParticleEpisode],
    summary: DescriptiveSummary,
    out_dir: str,
) -> str:
    """Overlay particle-average SOC vs time for all particles."""
    fig, ax = plt.subplots()
    for ep in episodes:
        mean_soc = []
        for t in range(ep.soc_movie_tyx.shape[0]):
            v = ep.soc_movie_tyx[t][ep.valid_mask_tyx[t]]
            v = v[np.isfinite(v)]
            mean_soc.append(np.mean(v) if len(v) else np.nan)
        ax.plot(ep.time_s / 3600, mean_soc, label=f"P{ep.particle_id}", alpha=0.8)
    ax.set_xlabel("Time (h)")
    ax.set_ylabel("Mean SOC")
    ax.legend(loc="best", fontsize=8)
    ax.set_title("Particle-average SOC vs time")
    out_path = _ensure_dir(out_dir) / "particle_soc_curves.png"
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    return str(out_path)


def plot_dc_dt_vs_c(
    episodes: List[ParticleEpisode],
    rate_maps_list: List[RateMaps],
    out_dir: str,
) -> str:
    """Scatter dc/dt vs c (and binned mean). dc/dt uses T-1 time axis (midpoints)."""
    fig, ax = plt.subplots()
    all_c, all_dc = [], []
    for ep, rate in zip(episodes, rate_maps_list):
        # dc_dt is (T-1, Y, X); align c to midpoints: use c at t and t+1 average
        T = ep.soc_movie_tyx.shape[0]
        c_mid = (ep.soc_movie_tyx[:-1] + ep.soc_movie_tyx[1:]) / 2
        for t in range(T - 1):
            v = rate.valid_mask_tyx[t] & np.isfinite(rate.dc_dt_tyx[t]) & np.isfinite(c_mid[t])
            if np.any(v):
                all_c.extend(c_mid[t][v].ravel())
                all_dc.extend(rate.dc_dt_tyx[t][v].ravel())
    all_c = np.array(all_c)
    all_dc = np.array(all_dc)
    if len(all_c) > 1000:
        idx = np.random.choice(len(all_c), 1000, replace=False)
        ax.scatter(all_c[idx], all_dc[idx], alpha=0.2, s=5)
    else:
        ax.scatter(all_c, all_dc, alpha=0.3, s=5)
    # Binned mean
    if len(all_c) > 10:
        bins = np.linspace(0, 1, 11)
        dig = np.digitize(all_c, bins)
        bin_centers = (bins[:-1] + bins[1:]) / 2
        bin_means = [np.nanmean(all_dc[dig == i]) for i in range(1, len(bins))]
        valid = [np.isfinite(m) for m in bin_means]
        if any(valid):
            ax.plot(bin_centers, bin_means, "k-", lw=2, label="Binned mean")
    ax.set_xlabel("SOC (midpoint)")
    ax.set_ylabel("dc/dt")
    ax.set_title("dc/dt vs c (T-1 midpoints)")
    ax.axhline(0, color="gray", ls="--")
    out_path = _ensure_dir(out_dir) / "dc_dt_vs_c.png"
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    return str(out_path)


def plot_heterogeneity_vs_time(
    summary: DescriptiveSummary,
    out_dir: str,
) -> str:
    """Within-particle std SOC vs time (and global mean)."""
    fig, ax = plt.subplots()
    for p in summary.per_particle:
        t_s = p["time_s"]
        std_soc = p["std_soc_t"]
        ax.plot(t_s / 3600, std_soc, alpha=0.7, label=f"P{p['particle_id']}")
    ax.set_xlabel("Time (h)")
    ax.set_ylabel("Std SOC within particle")
    ax.legend(loc="best", fontsize=8)
    ax.set_title("Heterogeneity (std SOC) vs time")
    out_path = _ensure_dir(out_dir) / "heterogeneity_vs_time.png"
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    return str(out_path)


def plot_valid_coverage(
    summary: DescriptiveSummary,
    out_dir: str,
) -> str:
    """Fraction valid SOC and fraction valid dc/dt per particle over time."""
    fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
    for p in summary.per_particle:
        t_s = p["time_s"]
        ax1.plot(t_s / 3600, p["frac_valid_soc_t"], alpha=0.7, label=f"P{p['particle_id']}")
    ax1.set_ylabel("Frac valid SOC")
    ax1.legend(loc="best", fontsize=8)
    ax1.set_title("Valid SOC coverage")
    for p in summary.per_particle:
        t_mid = p["time_mid_s"]
        ax2.plot(t_mid / 3600, p["frac_valid_dc_dt_t"], alpha=0.7, label=f"P{p['particle_id']}")
    ax2.set_xlabel("Time (h)")
    ax2.set_ylabel("Frac valid dc/dt")
    ax2.legend(loc="best", fontsize=8)
    ax2.set_title("Valid dc/dt coverage (T-1 midpoints)")
    out_path = _ensure_dir(out_dir) / "valid_coverage.png"
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    return str(out_path)


def plot_all(
    episodes: List[ParticleEpisode],
    rate_maps_list: List[RateMaps],
    summary: DescriptiveSummary,
    out_dir: str,
) -> List[str]:
    """Generate all figures. Returns list of saved paths."""
    paths = []
    paths.append(plot_particle_soc_curves(episodes, summary, out_dir))
    paths.append(plot_dc_dt_vs_c(episodes, rate_maps_list, out_dir))
    paths.append(plot_heterogeneity_vs_time(summary, out_dir))
    paths.append(plot_valid_coverage(summary, out_dir))
    return paths
